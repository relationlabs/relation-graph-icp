export const idlFactory = ({ IDL }) => {
  return IDL.Service({
    'acl_grant' : IDL.Func([IDL.Text, IDL.Text], [IDL.Text], []),
    'acl_revoke' : IDL.Func([IDL.Text], [IDL.Text], []),
    'acl_show' : IDL.Func([IDL.Nat], [IDL.Text], ['query']),
    'sparql_query' : IDL.Func([IDL.Text, IDL.Text], [IDL.Text], ['query']),
    'sparql_update' : IDL.Func([IDL.Text], [IDL.Text], []),
  });
};
export const init = ({ IDL }) => { return []; };
